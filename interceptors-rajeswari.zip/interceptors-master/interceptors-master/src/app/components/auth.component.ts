import { Component } from "@angular/core";

@Component({
  template: `
    <img src="../../assets/digger.gif" />
  `
})
export class AuthComponent {}
